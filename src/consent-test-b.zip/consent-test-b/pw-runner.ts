// src/consent-test-b/pw-runner.ts

import { chromium, Browser, BrowserContext, Page, ElementHandle, Frame, Locator } from 'playwright';
import { defaultConfig, ConsentTestConfig } from './config';
import * as fs from 'fs/promises';
import { z } from 'zod';
import { consentProbe } from './init/consent-probe';
import { waitForConsentOrTimeout } from './utils/wait-consent';

// ========================================
// 🧩 Cookiebot Helper Functions
// ========================================

type CookiebotCategory = 'statistics' | 'marketing' | 'preferences';

const CB_IDS: Record<CookiebotCategory, { input: string; label: string }> = {
  statistics:  { 
    input: '#CybotCookiebotDialogBodyLevelButtonStatistics',  
    label: 'label[for="CybotCookiebotDialogBodyLevelButtonStatistics"]' 
  },
  marketing:   { 
    input: '#CybotCookiebotDialogBodyLevelButtonMarketing',   
    label: 'label[for="CybotCookiebotDialogBodyLevelButtonMarketing"]' 
  },
  preferences: { 
    input: '#CybotCookiebotDialogBodyLevelButtonPreferences', 
    label: 'label[for="CybotCookiebotDialogBodyLevelButtonPreferences"]' 
  },
};

async function openCookiebotDetails(bannerScope: Page | Frame) {
  const triggers = [
    '#CybotCookiebotDialogBodyButtonDetails',
    'button:has-text("Mostra dettagli")',
    'button:has-text("Dettagli")',
    'button:has-text("Show details")',
  ];
  for (const sel of triggers) {
    const btn = bannerScope.locator(sel).first();
    if (await btn.isVisible().catch(() => false)) {
      await btn.click({ force: true });
      console.log(`✅ Clicked details button: ${sel}`);
      break;
    }
  }
}

async function waitCookiebotToggles(scope: Page | Frame) {
  const anyId = Object.values(CB_IDS).map(m => m.input).join(',');
  await Promise.race([
    scope.locator('#CybotCookiebotDialogBodyLevelButtons').waitFor({ state: 'visible', timeout: 8000 }),
    scope.locator(anyId).first().waitFor({ state: 'attached', timeout: 8000 }),
  ]).catch(() => {});
  await scope.waitForTimeout(150);
}

async function saveCookiebot(scope: Page | Frame) {
  // 🔍 DEBUG: Stampa tutti i pulsanti disponibili dopo aver settato i toggle
  console.log('📋 DEBUG: Tutti i pulsanti nel banner dopo aver settato i toggle:');
  try {
    const allButtons = await scope.evaluate(() => {
      const buttons = Array.from(document.querySelectorAll('#CybotCookiebotDialog button, #CybotCookiebotDialog [role="button"], #CybotCookiebotDialog a[role="button"]'));
      return buttons.map(btn => ({
        tagName: btn.tagName,
        text: btn.textContent?.trim() || '',
        id: btn.id || '',
        className: btn.className || '',
        role: btn.getAttribute('role') || '',
        outerHTML: btn.outerHTML.substring(0, 200) + '...'
      }));
    });
    
    // Debug logging rimosso per evitare output eccessivo
    
    // 🔍 DEBUG: Stampa anche tutti gli elementi con testo che contiene "salva", "conferma", "accept", "ok"
    const relevantElements = await scope.evaluate(() => {
      const elements = Array.from(document.querySelectorAll('#CybotCookiebotDialog *'));
      return elements
        .filter(el => {
          const text = el.textContent?.toLowerCase() || '';
          return text.includes('salva') || text.includes('conferma') || text.includes('accept') || 
                 text.includes('save') || text.includes('confirm') || text.includes('ok') ||
                 text.includes('accetta') || text.includes('conferma');
        })
        .map(el => ({
          tagName: el.tagName,
          text: el.textContent?.trim() || '',
          id: el.id || '',
          className: el.className || '',
          role: el.getAttribute('role') || ''
        }));
    });
    
    if (relevantElements.length > 0) {
      // Debug logging rimosso per evitare output eccessivo
    }
    
  } catch (e) {
    console.log('⚠️ Errore durante debug DOM per salvataggio:', e);
  }

  const save = scope.locator(
    '#CybotCookiebotDialogBodyLevelButtonAccept,' +
    'button:has-text("Salva"), button:has-text("Conferma"), button:has-text("Accept selected")'
  ).first();
  await save.click({ force: true });
  console.log('✅ Clicked save/confirm button');
}

async function isClickable(locator: Locator) {
  const h = await locator.elementHandle();
  if (!h) return false;
  return await h.evaluate((n: any) => {
    const r = n.getBoundingClientRect();
    const s = getComputedStyle(n);
    return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
  }).catch(() => false);
}

// Type-guard: verifica che sia davvero un Frame Playwright
function isRealFrame(x: any): x is Frame {
  return !!x && typeof x.url === 'function' && typeof x.locator === 'function';
}

// ========================================
// Schema di validazione per l'input
export const ConsentTestInputSchema = z.object({
  url: z.string().url().refine(url => url.startsWith('http://') || url.startsWith('https://'), {
    message: "URL deve iniziare con http:// o https://"
  }),
  options: z.object({
    timeoutSoftMs: z.number().optional().default(10000),
    timeoutHardMs: z.number().optional().default(25000),
    captureScreens: z.boolean().optional().default(true),
    trace: z.boolean().optional().default(false),
    region: z.enum(['EU', 'US']).optional().default('EU'),
  }).optional().default({})
});

export type ConsentTestInput = z.infer<typeof ConsentTestInputSchema>;

export type ScenarioMode = 'accept' | 'reject' | { custom: { analytics?: boolean; marketing?: boolean; preferences?: boolean } };

export interface ConsentTestResult {
  engine: string;
  url: string;
  generatedAt: string;
  summary: {
    pass: boolean;
    notes: string[];
  };
  results: {
    reject: ScenarioResult;
    accept: ScenarioResult;
    [key: string]: ScenarioResult;  // Support per scenari custom dinamici
  };
  env: {
    userAgent: string;
    locale: string;
    region: string;
  };
}

export interface ScenarioResult {
  latestConsent: {
    ad_user_data: string;
    ad_personalization: string;
    ad_storage: string;
    analytics_storage: string;
  };
  cookies: Array<{
    name: string;
    domain: string;
    expires: number;
  }>;
  gaAdsRequests: Array<{
    url: string;
    ts: number;
  }>;
  gtagCalls: Array<[string, string, any]>;
  dataLayer: Array<any>;
  artifacts: {
    screenshotPath?: string;
    tracePath?: string;
  };
  selectedCategories?: {
    analytics?: boolean;
    marketing?: boolean;
    preferences?: boolean;
  };
  personalizaFlow?: {
    usedCmp?: 'cookiebot' | 'onetrust' | 'iubenda' | 'didomi' | 'usercentrics' | 'generic' | 'unknown';
    usedIframe?: boolean;
    matchedBy?: 'config' | 'fallback';
    confirmButton?: string;
    missingToggle?: string[];
  };
}

export class ConsentTestRunner {
  private config: ConsentTestConfig;

  constructor(config: ConsentTestConfig = defaultConfig) {
    this.config = config;
  }

  async runTest(input: ConsentTestInput, customScenarios?: Array<ScenarioMode>): Promise<ConsentTestResult> {
    const validatedInput = ConsentTestInputSchema.parse(input);
    
    console.log(`🎯 pw-runner: Received customScenarios:`, customScenarios);
    if (customScenarios && customScenarios.length > 0) {
      console.log(`🎯 pw-runner: Custom scenarios count:`, customScenarios.length);
    }
    
    let rejectResult: ScenarioResult;
    let acceptResult: ScenarioResult;
    const customResults: { [key: string]: ScenarioResult } = {};

    try {
      // Scenario REJECT
      console.log('=== INIZIO SCENARIO REJECT ===');
      rejectResult = await this.runScenarioWithIsolatedBrowser('reject', validatedInput);
      
      // Scenario ACCEPT con browser completamente nuovo
      console.log('=== INIZIO SCENARIO ACCEPT ===');
      acceptResult = await this.runScenarioWithIsolatedBrowser('accept', validatedInput);

      // Scenari custom se presenti
      if (customScenarios && customScenarios.length > 0) {
        console.log(`🎯 Scenari personalizzati ricevuti: ${customScenarios.length}`);
        for (const scenario of customScenarios) {
          console.log(`🔍 Validating scenario: ${typeof scenario} - ${JSON.stringify(scenario)}`);
          if (typeof scenario === 'object' && scenario !== null && 'custom' in scenario) {
            const scenarioKey = `custom-${JSON.stringify(scenario.custom).replace(/[{":]/g, '').replace(/}/g, '')}`;
            console.log(`=== INIZIO SCENARIO CUSTOM: ${scenarioKey} ===`);
            const customResult = await this.runScenarioWithIsolatedBrowser(scenario, validatedInput);
            customResults[scenarioKey] = customResult;
          } else {
            console.log(`❌ Scenario custom failed validation conditions`);
          }
        }
      } else {
        console.log(`⚠️ NO CUSTOM SCENARIOS ENABLED (customScenarios=${!!customScenarios}, length=${customScenarios?.length || 0})`);
      }

      const results = {
        reject: rejectResult,
        accept: acceptResult,
        ...customResults
      };

      const summary = this.evaluateResults(results);
      
      return {
        engine: 'playwright',
        url: validatedInput.url,
        generatedAt: new Date().toISOString(),
        summary,
        results,
        env: {
          userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
          locale: 'it-IT',
          region: validatedInput.options.region
        }
      };
    } catch (error) {
      console.error('Errore durante i test:', error);
      throw error;
    }
  }

  private async runScenarioWithIsolatedBrowser(scenario: ScenarioMode, input: ConsentTestInput): Promise<ScenarioResult> {
    let browser: Browser | null = null;
    let context: BrowserContext | null = null;
    let page: Page | null = null;

    try {
      console.log(`🚀 Creando browser isolato per scenario ${scenario}...`);
      browser = await chromium.launch({
        headless: true,
        args: [
          '--no-sandbox', 
          '--disable-setuid-sandbox', 
          '--disable-dev-shm-usage',
          '--disable-gpu',
          '--no-first-run',
          '--disable-background-timer-throttling',
          '--disable-backgrounding-occluded-windows',
          '--disable-renderer-backgrounding',
          '--disable-features=TranslateUI',
          '--disable-features=VizDisplayCompositor'
        ]
      });

      // Crea un nuovo context completamente isolato per ogni scenario
      context = await browser.newContext({
        storageState: undefined, // Forza modalità incognito
        locale: 'it-IT',
        timezoneId: this.config.region === 'EU' ? 'Europe/Rome' : 'America/New_York',
        userAgent: scenario === 'reject' 
          ? 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
          : 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        viewport: { width: 1920, height: 1080 },
        geolocation: { latitude: 41.9028, longitude: 12.4964 }, // Roma per test EU
        permissions: ['geolocation'],
        acceptDownloads: false,
        bypassCSP: true,
        ignoreHTTPSErrors: true
      });

      // FIX A: Hook PRIMA della navigazione (serializzazione sicura)
      await context.addInitScript({ content: `(${consentProbe.toString()})();` });

      // FIX C: Context-level request monitoring migliorato
      const gaAdsRequests: Array<{ url: string, ts: number }> = [];
      
      await context.route('**/*', route => {
        const url = route.request().url();
        if (
          url.includes('google-analytics.com/g/collect') ||
          url.includes('region1.google-analytics.com/g/collect') ||
          url.includes('stats.g.doubleclick.net') ||
          url.includes('googleads.g.doubleclick.net') ||
          url.includes('td.doubleclick.net') ||
          url.includes('www.googletagmanager.com/gtag/js')
        ) {
          gaAdsRequests.push({ url, ts: Date.now() });
          console.log(`🔗 GA/Ads request detected: ${url}`);
        }
        route.continue();
      });

      page = await context.newPage();
      
      // Sanity check dell'injection dopo creazione page
      await page.addInitScript(() => {}); // no-op, forza il preload del init script
      
      // URL con parametri per forzare pop-up banner
      let scenarioKey = '';
      if (typeof scenario === 'string') {
        scenarioKey = scenario; // 'accept' or 'reject'
      } else {
        // Custom scenario: formato breve per debug
        const settings = scenario.custom;
        scenarioKey = `custom-a${+!!settings.analytics}m${+!!settings.marketing}p${+!!settings.preferences}`;
      }
      
      const urlWithParam = `${input.url}${input.url.includes('?') ? '&' : '?'}cb=1&test_consent=${encodeURIComponent(scenarioKey)}&_t=${Date.now()}`;
      console.log(`🌐 Navigating to: ${urlWithParam}`);
      
      try {
        await page.goto(urlWithParam, { 
          waitUntil: 'domcontentloaded', 
          timeout: input.options.timeoutHardMs 
        });
      } catch (error) {
        console.log(`⚠️ Navigazione con parametri custom fallita, riprovo con URL base...`);
        // Fallback: retry with base URL if custom params cause issues
        await page.goto(input.url, { 
          waitUntil: 'domcontentloaded', 
          timeout: input.options.timeoutHardMs 
        });
      }

      // API injection check rimosso - la verifica avviene ora nel waitForConsentOrTimeout

      // Attendi il caricamento completo della pagina e eventuali banner
      console.log(`⏱️ Attendo ${this.config.timeouts.softMs}ms per caricamento banner...`);
      await page.waitForTimeout(this.config.timeouts.softMs);

      // Pipeline per gestire il banner e cliccare l'azione corrispondente
      const bannerHandled = await this.handleBannerDetectionAndAction(page, scenario, input);
      
      // FIX B: Attesa stabilizzazione CONSENT (soft)
      const settle = await waitForConsentOrTimeout(page, input.options.timeoutSoftMs);
      console.log(`[${scenario}] consent settle in ${settle.ms}ms`, settle.snapshot?.last || 'n/d');

      // Patch 4: Se probe fallito, usa Cookiebot mappato
      let latestConsent;
      
      if (settle.snapshot?.last) {
        // Il probe funziona - usa snapshot
        latestConsent = settle.snapshot.last;
      } else {
        // Fallback Cookiebot mapping
        const cbSnap = await page.evaluate(() => {
          const w: any = window;
          const cb = w.Cookiebot;
          if (!cb || !cb.consent) return null;
          return {
            marketing: !!cb.consent.marketing,
            statistics: !!cb.consent.statistics
          };
        });
        
        if (cbSnap) {
          console.log(`[${scenario}] Cookiebot raw ->`, cbSnap);
          // Mappa Cookiebot → Consent Mode v2
          latestConsent = {
            ad_user_data: cbSnap.marketing ? 'granted' : 'denied',
            ad_personalization: cbSnap.marketing ? 'granted' : 'denied',
            ad_storage: cbSnap.marketing ? 'granted' : 'denied',
            analytics_storage: cbSnap.statistics ? 'granted' : 'denied'
          };
        } else {
          // Ultimo fallback n/d
          latestConsent = {
            ad_user_data: 'n/d',
            ad_personalization: 'n/d', 
            ad_storage: 'n/d',
            analytics_storage: 'n/d'
          };
        }
      }
      const cookies = await this.getSensitiveCookies(context);
      const gtagCalls = await this.getGtagCallsData(page);
      const dataLayerEvents = await this.getDataLayerEvents(page);

      // Cattura screenshot (opzionale)
      const screenshotPath = await this.captureScreenshot(page, scenario, input);

      // Build selected categories metadata per scenarios custom 
      let selectedCategories = undefined;
      let personalizaFlow = undefined;
      
      if (scenario !== 'accept' && scenario !== 'reject' && scenario.custom) {
        const customPrefs = scenario.custom;
        selectedCategories = {
          analytics: customPrefs.analytics,
          marketing: customPrefs.marketing,
          preferences: customPrefs.preferences
        };

        // Dobbiamo aggiungere logic per extracting il metadata effettive personal info
        const personalizeButtonFound = await this.detectPersonalizeCmpInfo(page);        
        personalizaFlow = {
          usedCmp: personalizeButtonFound.cmpName,
          usedIframe: false, // Guess per ora, potrebbe essere ricavati via further analysis
          matchedBy: personalizeButtonFound.matchedBy,
          confirmButton: personalizeButtonFound.confirmButtonText
        };
      }

      return {
        latestConsent,
        cookies,
        gaAdsRequests,
        gtagCalls,
        dataLayer: dataLayerEvents,
        artifacts: { screenshotPath },
        selectedCategories,
        personalizaFlow 
      };

    } finally {
      // IMPORTANTE: sempre chiudere browser per liberare risorse
      try { if (page) await page.close(); } catch {};
      try { if (context) await context.close(); } catch {};
      try { if (browser) await browser.close(); } catch {};
    }
  }

  private async handleBannerDetectionAndAction(page: Page, scenario: ScenarioMode, input: ConsentTestInput): Promise<boolean> {
    try {
      console.log(`🔍 Cerco banner per scenario ${scenario}...`);
      
      // Lista selettori banner CMP supportati
      const bannerSelectors = [
        '#onetrust-consent-sdk',
        '#CybotCookiebotDialog', 
        '.iubenda-cs-banner',
        '.didomi-popup',
        '.uc-banner',
        '[id*="cookie"]',
        '[class*="cookie"]'
      ];

      // Attendi cenna fino a 15 secondi per l'apparizione del banner
      for (let attempt = 0; attempt < 15; attempt++) {
        console.log(`🔄 Tentativo rilevamento banner ${attempt + 1}/15...`);
        
        for (const selector of bannerSelectors) {
          try {
            const banner = await page.$(selector);
            if (banner && await banner.isVisible()) {
              console.log(`✅ Banner trovato: ${selector}`);
              
              let actionResult = false;
              if (scenario === 'accept' || scenario === 'reject') {
                actionResult = await this.performConsentAction(page, scenario, selector);
              } else {
                // Scenario custom: gestione flow personalizza
                actionResult = await this.handleCustomScenario(page, scenario, selector);
              }
              
              if (actionResult) {
                console.log(`✅ Azione ${JSON.stringify(scenario)} completata con successo`);
                return true;
              } else {
                console.log(`⚠️ Banner trovato ma azione ${JSON.stringify(scenario)} fallita`);
              }
            }
          } catch (err) {
            console.log(`❌ Errore nel verificare banner ${selector}:`, err.message);
          }
        }
        
        // Fallback: cerca per testo in tutti gli elementi clickable
        let actionResult = false;
        if (scenario === 'accept' || scenario === 'reject') {
          actionResult = await this.performFallbackConsentAction(page, scenario);
        } else {
          actionResult = await this.handleCustomScenarioFallback(page, scenario);
        }
        
        if (actionResult) {
          console.log(`✅ Fallback ${JSON.stringify(scenario)} completato`);
          return true;
        }
        
        await page.waitForTimeout(1000); // Attendi 1 secondo
      }

      console.log(`⚠️ Banner non trovato nel timeout, continuo con raccolta dati`);
      return false;
    } catch (error) {
      console.error('❌ Errore gestione banner:', error);
      return false;
    }
  }

  private async performConsentAction(page: Page, scenario: 'reject' | 'accept', bannerSelector: string): Promise<boolean> {
    try {
      // Esegui tutto nel contesto della pagina
      return await page.evaluate(({ scenario, bannerSelector }) => {
        const keywords = scenario === 'reject' 
          ? ['rifiuta', 'decline', 'reject', 'necessari', 'deny', 'rifiuto', 'nega', 'solo essenziali']
          : ['accetta', 'accept', 'consenti', 'consent', 'tutti', 'conferma', 'allow', 'agree'];

        const scope = document.querySelector(bannerSelector);
        if (!scope) return false;
        
        // Cerca tutti i pulsanti/interazioni nel banner
        const elements = Array.from(scope.querySelectorAll('button, a, [role="button"], input, .btn, [onclick]'));
        
        for (const btn of elements) {
          const text = (btn.textContent || '').toLowerCase().trim();
          const ariaLabel = (btn.getAttribute('aria-label') || '').toLowerCase().trim();
          const combinedText = `${text} ${ariaLabel}`;
          
          for (const keyword of keywords) {
            if (combinedText.includes(keyword.toLowerCase())) {
              console.log(`🎯 Clicking element: "${text}" (keyword: ${keyword})`);
              (btn as HTMLElement).click();
              return true;
            }
          }
        }
        
        return false;
      }, { scenario, bannerSelector });

    } catch (error) {
      console.log(`❌ Errore click ${scenario}:`, error.message);
      return false;
    }
  }

  private async performFallbackConsentAction(page: Page, scenario: 'reject' | 'accept'): Promise<boolean> {
    try {
      const selectors = scenario === 'accept' ? 
        this.getAllAcceptSelectors() : 
        this.getAllRejectSelectors();

      for (const selector of selectors) {
        try {
          const element = await page.$(selector);
          if (element && await element.isVisible()) {
            console.log(`🎯 Clicking ${scenario} with selector: ${selector}`);
            await element.click();
            return true;
          }
        } catch (error) {
          console.log(`❌ Failed click ${scenario} selector ${selector}:`, error.message);
        }
      }
      
      // Ultimo fallback: match text su tutti i button della pagina
      const result = await page.evaluate((scenario) => {
        const keywords = scenario === 'reject' 
          ? ['rifiuta', 'decline', 'reject', 'necessari', 'deny']
          : ['accetta', 'accept', 'consenti', 'consent', 'conferma'];

        const allButtons = Array.from(document.querySelectorAll('button, a, [role="button"], input, [onclick]'));
        
        for (const btn of allButtons) {
          const text = (btn.textContent || '').toLowerCase().trim();
          if (keywords.some(k => text.includes(k.toLowerCase().trim()))) {
            console.log(`🎯 Clicking fallback ${scenario}: "${text}"`);
            (btn as HTMLElement).click();
            return true;
          }
        }
        return false;
      }, scenario);

      return result;
    } catch (error) {
      console.log(`❌ Fallback ${scenario} failed:`, error.message);
      return false;
    }
  }

  private async getLatestConsentState(page: Page): Promise<ScenarioResult['latestConsent']> {
    return await page.evaluate(() => {
      const w = window as any;
      
      // Cerca eventi consent nel dataLayer
      const dl = w.__dl_events || [];
      let latestConsent: any = {};

      // Pattern di ricerca nelle chiamate gtag
      const gtagCalls = w.__gtag_calls || [];
      for (const call of gtagCalls.reverse()) {
        if (call[0] === 'consent' && call[1] === 'update' && call[2]) {
          latestConsent = { ...call[2] };
          break;
        }
      }

      // Pattern di ricerca nel dataLayer
      for (const event of dl.slice().reverse()) {
        if (Array.isArray(event)) {
          if (event[0] === 'consent') {
            latestConsent = { ...(event[1] || {}) };
            break;
          }
          if (event[0] === 'gtag' && event[1] === 'consent') {
            latestConsent = { ...(event[2] || {}) };
            break;
          }
        } else if (typeof event === 'object' && event.event) {
          if (event.event.includes('consent')) {
            latestConsent = { ...(event.consent_mode || {}) };
            break;
          }
        }
      }

      return {
        ad_user_data: latestConsent.ad_user_data || 'n/d',
        ad_personalization: latestConsent.ad_personalization || 'n/d',
        ad_storage: latestConsent.ad_storage || 'n/d',
        analytics_storage: latestConsent.analytics_storage || 'n/d'
      };
    });
  }

  private async getSensitiveCookies(context: BrowserContext): Promise<ScenarioResult['cookies']> {
    const cookies = await context.cookies();
    return cookies
      .filter(cookie => this.config.cookies.sensitive.includes(cookie.name))
      .map(cookie => ({
        name: cookie.name,
        domain: cookie.domain,
        expires: cookie.expires || 0
      }));
  }

  private async getGtagCallsData(page: Page): Promise<ScenarioResult['gtagCalls']> {
    return await page.evaluate(() => (window as any).__gtag_calls || []);
  }

  private async getDataLayerEvents(page: Page): Promise<ScenarioResult['dataLayer']> {
    return await page.evaluate(() => (window as any).__dl_events || []);
  }

  private isGaAdsRequest(url: string): boolean {
    return this.config.endpoints.gaAds.some(pattern => {
      const regex = new RegExp(pattern.replace(/\*/g, '.*'));
      return regex.test(url);
    });
  }

  private getAllAcceptSelectors(): string[] {
    const selectors: string[] = [];
    Object.values(this.config.cmp.selectors).forEach(cmp => {
      selectors.push(...cmp.accept);
    });
    return selectors;
  }

  private getAllRejectSelectors(): string[] {
    const selectors: string[] = [];
    Object.values(this.config.cmp.selectors).forEach(cmp => {
      selectors.push(...cmp.reject);
    });
    return selectors;
  }

  private async captureScreenshot(page: Page, scenario: 'reject' | 'accept', input: ConsentTestInput): Promise<string | undefined> {
    try {
      if (!input.options.captureScreens) return undefined;
      
      const runId = Date.now().toString();
      const artifactPath = `./artifacts/${runId}/`;
      await fs.mkdir(artifactPath, { recursive: true }); 
      
      const filename = `${artifactPath}consent-test-${scenario}.png`;
      
      // Prima prova a trovare un cookie banner specifico nello schermo
      const bannerElement = await this.findCookieBannerElement(page);
      
      if (bannerElement) {
        // Screenshot solo dell'area del cookie banner
        await bannerElement.screenshot({ path: filename });
        console.log('✅ Cookie banner screenshot catturato');
      } else {
        // Fallback: screenshot dell'intera pagina
        await page.screenshot({ path: filename, fullPage: true });
        console.log('⚠️ Banner non trovato, screenshot full page catturato');
      }
      
      return filename;
    } catch { 
      return undefined; 
    }
  }

  private async findCookieBannerElement(page: Page): Promise<ElementHandle<Element> | null> {
    try {
      // Lista selettori comuni per cookie banner
      const bannerSelectors = [
        '[class*="cookie"]',
        '[id*="cookie"]',
        '[class*="banner"]',
        '[id*="banner"]',
        '[class*="consent"]',
        '[id*="consent"]',
        '[class*="gdpr"]',
        '[id*="gdpr"]',
        'div[role="dialog"]',
        '.cookie-notice',
        '.cookie-banner',
        '.consent-banner',
        '#cookie-notice',
        '#cookie-banner',
        '#consent-banner',
        '[data-cookie-policy]',
        '[data-gdpr-notice]'
      ];

      for (const selector of bannerSelectors) {
        const element = await page.$(selector);
        if (element) {
          // Verifichiamo che sia visibile e probabilmente sia un cookie banner
          const isVisible = await element.isVisible();
          const boundingBox = await element.boundingBox();
          
          if (isVisible && boundingBox && boundingBox.height > 0 && boundingBox.width > 0) {
            // Controlliamo se contiene testo legato a cookie/consenso
            const text = await element.textContent();
            const cookieKeywords = ['cookie', 'consent', 'accetta', 'rifiuta', 'preferences', 'settings', 'agree', 'disagree'];
            
            if (text && cookieKeywords.some(keyword => 
              text.toLowerCase().includes(keyword.toLowerCase())
            )) {
              console.log(`✅ Banner trovato con selettore: ${selector}`);
              return element;
            }
          }
        }
      }
      
      // Fallback: cerca elementi con testo cookie common
      const candidates = await page.$$('*');
      for (const element of candidates.slice(0, 50)) { // Limita ricerca ai primi 50 elementi
        try {
          const text = await element.textContent();
          const className = await element.evaluate(el => el.className || '');
          const id = await element.evaluate(el => el.id || '');
          
          if (text && (
            text.toLowerCase().includes('cookie') ||
            text.toLowerCase().includes('consent') ||
            text.toLowerCase().includes('accetta') ||
            text.toLowerCase().includes('rifiuta') ||
            className.includes('cookie') ||
            id.includes('cookie')
          )) {
            const isVisible = await element.isVisible();
            const boundingBox = await element.boundingBox();
            
            if (isVisible && boundingBox && boundingBox.height > 0 && boundingBox.width > 0) {
              console.log(`✅ Banner trovato tramite testo: ${text.substring(0, 50)}...`);
              return element;
            }
          }
        } catch {
          // Ignora errori sui singoli elementi
          continue;
        }
      }
      
      return null;
    } catch {
      return null;
    }
  }

  private evaluateResults(results: { reject: ScenarioResult; accept: ScenarioResult; [key: string]: ScenarioResult }): ConsentTestResult['summary'] {
    const notes: string[] = [];
    let pass = true;

    // Controlli di sicurezza preliminari
    if (!results.reject || !results.accept) {
      notes.push('ERRORE: Risultati incompleti - uno o entrambi gli scenari sono falliti');
      return { pass: false, notes };
    }

    // ========================================
    // 1. Valuta scenario REJECT
    // ========================================
    const rejectCookies = results.reject.cookies?.length || 0;
    const rejectRequests = results.reject.gaAdsRequests?.length || 0;
    const rejectConsent = results.reject.latestConsent || {};
    
    if (rejectCookies > 0) {
      notes.push(`REJECT: 🍪 Rilevati ${rejectCookies} cookie sensibili (dovrebbero essere 0)`);
      pass = false;
    }
    
    if (rejectRequests > 0) {
      notes.push(`REJECT: 🎯 Trovate ${rejectRequests} richieste GA/Ads (dovrebbero essere 0)`);
      pass = false;
    }

    // Verifica che tutti i consensi siano 'denied' in REJECT
    const rejectHasGranted = Object.values(rejectConsent).some(value => value === 'granted');
    if (rejectHasGranted) {
      notes.push(`REJECT: ⚠️ Rilevati consensi "granted" nel Consent Mode (dovrebbero essere tutti "denied")`);
      pass = false;
    }

    // ========================================
    // 2. Valuta scenario ACCEPT
    // ========================================
    const acceptConsent = results.accept.latestConsent || {};
    const hasGrantedConsent = Object.values(acceptConsent).some(value => value === 'granted');
    const acceptRequests = results.accept.gaAdsRequests?.length || 0;
    const acceptCookies = results.accept.cookies?.length || 0;

    if (!hasGrantedConsent) {
      notes.push('ACCEPT: ⚠️ Nessun consenso "granted" rilevato dal Consent Mode');
      pass = false;
    }

    // Test dovrebbe anche controllare che in ACCEPT ci siano tracking calls
    if (acceptRequests === 0 && acceptCookies === 0) {
      notes.push('ACCEPT: ⚠️ Nessuna attività tracking (potrebbe essere normale se il sito non usa GA/Ads)');
    }

    // ========================================
    // 3. Valuta scenari CUSTOM (se presenti)
    // ========================================
    const customScenarios = Object.keys(results).filter(key => key.startsWith('custom-'));
    
    if (customScenarios.length > 0) {
      console.log(`🎯 Evaluating ${customScenarios.length} custom scenarios...`);
      
      for (const scenarioKey of customScenarios) {
        const scenarioResult = results[scenarioKey];
        const selectedCategories = scenarioResult.selectedCategories;
        
        if (!selectedCategories) {
          notes.push(`CUSTOM [${scenarioKey}]: ⚠️ Nessuna categoria selezionata rilevata`);
          continue;
        }

        const consent = scenarioResult.latestConsent || {};
        const scenarioNotes: string[] = [];
        let scenarioPass = true;

        // Valida ANALYTICS
        if (selectedCategories.analytics === true) {
          if (consent.analytics_storage !== 'granted') {
            scenarioNotes.push(`analytics_storage dovrebbe essere "granted" ma è "${consent.analytics_storage}"`);
            scenarioPass = false;
          }
        } else if (selectedCategories.analytics === false) {
          if (consent.analytics_storage === 'granted') {
            scenarioNotes.push(`analytics_storage dovrebbe essere "denied" ma è "granted"`);
            scenarioPass = false;
          }
        }

        // Valida MARKETING
        if (selectedCategories.marketing === true) {
          // Marketing richiede tutti i parametri ad_* granted
          const marketingParams = ['ad_storage', 'ad_personalization', 'ad_user_data'];
          for (const param of marketingParams) {
            if (consent[param as keyof typeof consent] !== 'granted') {
              scenarioNotes.push(`${param} dovrebbe essere "granted" ma è "${consent[param as keyof typeof consent]}"`);
              scenarioPass = false;
            }
          }
        } else if (selectedCategories.marketing === false) {
          // Marketing disabilitato richiede tutti i parametri ad_* denied
          const marketingParams = ['ad_storage', 'ad_personalization', 'ad_user_data'];
          for (const param of marketingParams) {
            if (consent[param as keyof typeof consent] === 'granted') {
              scenarioNotes.push(`${param} dovrebbe essere "denied" ma è "granted"`);
              scenarioPass = false;
            }
          }
        }

        // Valida PREFERENCES (opzionale, solitamente sempre granted)
        // Le preferences sono cookie tecnici necessari, quindi non causano fail
        
        // Aggiungi note per questo scenario custom
        if (scenarioPass) {
          notes.push(`CUSTOM [${this.formatCustomScenarioName(selectedCategories)}]: ✅ Validazione superata`);
        } else {
          pass = false;
          notes.push(`CUSTOM [${this.formatCustomScenarioName(selectedCategories)}]: ❌ ${scenarioNotes.join(', ')}`);
        }

        // Verifica anche cookies e richieste per coerenza
        const customCookies = scenarioResult.cookies?.length || 0;
        const customRequests = scenarioResult.gaAdsRequests?.length || 0;

        // Se marketing è disabled, non dovrebbero esserci richieste ads
        if (selectedCategories.marketing === false && customRequests > 0) {
          notes.push(`CUSTOM [${this.formatCustomScenarioName(selectedCategories)}]: ⚠️ Marketing disabilitato ma rilevate ${customRequests} richieste GA/Ads`);
        }
      }
    }

    // ========================================
    // 4. Messaggio finale
    // ========================================
    if (notes.length === 0) {
      notes.push('✅ Test completato con successo - nessun problema rilevato');
    }

    return { pass, notes };
  }

  /**
   * Formatta il nome dello scenario custom per i messaggi
   */
  private formatCustomScenarioName(categories: { analytics?: boolean; marketing?: boolean; preferences?: boolean }): string {
    const parts: string[] = [];
    if (categories.analytics !== undefined) parts.push(`Analytics:${categories.analytics ? 'ON' : 'OFF'}`);
    if (categories.marketing !== undefined) parts.push(`Marketing:${categories.marketing ? 'ON' : 'OFF'}`);
    if (categories.preferences !== undefined) parts.push(`Preferences:${categories.preferences ? 'ON' : 'OFF'}`);
    return parts.join(', ');
  }

  // Implementazione scenario custom
  private async handleCustomScenario(page: Page, scenario: ScenarioMode, bannerSelector: string): Promise<boolean> {
    if (scenario === 'accept' || scenario === 'reject') {
      return this.performConsentAction(page, scenario, bannerSelector);
    }

    const prefs = scenario.custom;
    console.log(`🛠️ Handling custom scenario with preferences:`, prefs);

    try {
      // 1) Click "Personalizza" se visibile
      const personalizeBtn = page.getByRole('button', { name: /personalizza|impostazioni|gestisci|mostra dettagli/i }).first();
      if (await personalizeBtn.isVisible().catch(() => false)) {
        await personalizeBtn.click({ force: true });
        console.log('✅ Clicked personalize');
      }

      // Piccola attesa per transizione
      await page.waitForTimeout(150);

      // 2) Apri sezione "Dettagli" se necessario
      await openCookiebotDetails(page);

      // 3) Trova lo scope (main o iframe)
      const detailsScope = await this.getCookiebotDetailsScope(page);

      // 4) Attendi toggle visibili
      await waitCookiebotToggles(detailsScope);

      // 5) Mappa analytics → statistics e toggla
      await this.toggleCookiebotCheckbox(detailsScope, 'CybotCookiebotDialogBodyLevelButtonStatistics', !!prefs.analytics, 'analytics');
      await this.toggleCookiebotCheckbox(detailsScope, 'CybotCookiebotDialogBodyLevelButtonMarketing', !!prefs.marketing, 'marketing');
      await this.toggleCookiebotCheckbox(detailsScope, 'CybotCookiebotDialogBodyLevelButtonPreferences', !!prefs.preferences, 'preferences');

      // 6) Salva
      await saveCookiebot(detailsScope);

      // 7) Assert Cookiebot.consent
      const cb = await page.evaluate(() => (window as any).Cookiebot?.consent ?? null);
      console.log('📊 Cookiebot raw ->', cb);
      if (!cb) {
        console.warn('⚠️ Cookiebot.consent non disponibile - possibile implementazione custom');
      } else {
        // Verifica che corrisponda (analytics -> statistics in Cookiebot)
        if (cb.statistics !== !!prefs.analytics || cb.marketing !== !!prefs.marketing || cb.preferences !== !!prefs.preferences) {
          console.warn(`⚠️ Consent mismatch: expected {statistics:${!!prefs.analytics}, marketing:${!!prefs.marketing}, preferences:${!!prefs.preferences}} got ${JSON.stringify(cb)}`);
        }
      }

      console.log('✅ Custom scenario flow completed successfully');
      return true;
      
    } catch (e) {
      console.error('Exception in handleCustomScenario():', e);
      return false;
    }
  }

  private async clickPersonalizeButton(page: Page): Promise<{clicked: boolean; error?: string; cmpDetected?: string}> {
    // Search CMPs configuration
    const possibleCmps = Object.keys(this.config.cmp.selectors);
    
    for (const cmpName of possibleCmps) {
      const cmpConfig = this.config.cmp.selectors[cmpName];
      if (cmpConfig.personalize && cmpConfig.personalize.length > 0) {
        for (const selector of cmpConfig.personalize) {
          try {
            const elem = await page.$(selector);
            if (elem && await elem.isVisible()) {
              await elem.click();
              console.log(`✅ Clicked personalize with CMP selector ${cmpName}: ${selector}`);
              return { clicked: true, cmpDetected: cmpName };
            }
          } catch (err) { 
            // Continue iterating if element not found
          }
        }
      }
    }
    
    // Fallback: text-based matching
    if (this.config.cmp.fallback.personalize) {
      for (const keyword of this.config.cmp.fallback.personalize) {
        const result = await page.evaluate((k) => {
          const buttons = Array.from(document.querySelectorAll('button, .btn, [role="button"], a'));
          for (const btn of buttons) {
            const text = (btn.textContent || '').toLowerCase().trim();
            if (text.includes(k.toLowerCase())) {
              (btn as HTMLElement).click();
              return true;
            }
          }
          return false;
        }, keyword);
        
        if (result) {
          console.log(`✅ Fallback clicked personaliza button: "${keyword}"`);
          return { clicked: true, cmpDetected: 'generic' };
        }
      }
    }
    
    return { clicked: false, error: 'No personalize button found via configuration/fallback' };
  }

  async applyCustomPreferences(page: Page, prefs: {analytics?: boolean; marketing?: boolean; preferences?: boolean}, cmpName?: string): Promise<string[]> {
    const missingToggles: string[] = [];
    
    // For each category, scan field and toggle it
    const categories = [
      { key: 'analytics', value: prefs.analytics },
      { key: 'marketing', value: prefs.marketing },
      { key: 'preferences', value: prefs.preferences }
    ];
    
    for (const cat of categories) {
      if (cat.value === undefined) continue;
      
      const toggleSuccess = await this.toggleSwitchField(page, cat.key, cat.value, cmpName);
      if (!toggleSuccess) missingToggles.push(cat.key);
      console.log(`⚙️ Toggle ${cat.key}=${cat.value} completed`);
    }
    
    return missingToggles;
  }

  /**
   * ✅ Apre la sezione Dettagli Cookiebot e ritorna sempre page come scope
   * (i toggle vivono nel main DOM dopo l'apertura di "Dettagli")
   */
  private async getCookiebotDetailsScope(page: Page): Promise<Page | Frame> {
    // Sezione dettagli già visibile?
    const buttonsContainer = page.locator('#CybotCookiebotDialogBodyLevelButtons').first();
    
    if (!(await buttonsContainer.isVisible().catch(() => false))) {
      console.log('🔍 Dettagli non visibili, cercando pulsante "Dettagli"...');
      
      // 🔍 DEBUG: Stampa tutti i pulsanti disponibili nel banner
      console.log('📋 DEBUG: Tutti i pulsanti nel banner dopo "Personalizza":');
      try {
        const allButtons = await page.evaluate(() => {
          const buttons = Array.from(document.querySelectorAll('#CybotCookiebotDialog button, #CybotCookiebotDialog [role="button"], #CybotCookiebotDialog a[role="button"]'));
          return buttons.map(btn => ({
            tagName: btn.tagName,
            text: btn.textContent?.trim() || '',
            id: btn.id || '',
            className: btn.className || '',
            role: btn.getAttribute('role') || '',
            outerHTML: btn.outerHTML.substring(0, 200) + '...'
          }));
        });
        
        allButtons.forEach((btn, i) => {
          console.log(`  ${i+1}. <${btn.tagName}> "${btn.text}" (id="${btn.id}", class="${btn.className}", role="${btn.role}")`);
        });
        
        // 🔍 DEBUG: Stampa anche tutti gli elementi con testo che contiene "dettagli", "salva", "conferma", "accept"
        const relevantElements = await page.evaluate(() => {
          const elements = Array.from(document.querySelectorAll('#CybotCookiebotDialog *'));
          return elements
            .filter(el => {
              const text = el.textContent?.toLowerCase() || '';
              return text.includes('dettagli') || text.includes('salva') || text.includes('conferma') || 
                     text.includes('accept') || text.includes('save') || text.includes('confirm');
            })
            .map(el => ({
              tagName: el.tagName,
              text: el.textContent?.trim() || '',
              id: el.id || '',
              className: el.className || '',
              role: el.getAttribute('role') || ''
            }));
        });
        
        // Debug logging rimosso per evitare output eccessivo
        
      } catch (e) {
        console.log('⚠️ Errore durante debug DOM:', e);
      }
      
      // Prova ad aprire i dettagli (varie lingue/markup)
      const cands = [
        '#CybotCookiebotDialogBodyButtonDetails',
        'button:has-text("Dettagli")',
        'button:has-text("Mostra dettagli")',
        'button:has-text("Show details")',
        'a[role="button"]:has-text("Dettagli")',
        '[role="button"]:has-text("Dettagli")',
      ];

      for (const sel of cands) {
        const cand = page.locator(sel).first();
        if (await cand.count()) {
          await cand.scrollIntoViewIfNeeded().catch(() => {});
          await cand.click({ timeout: 4000 }).catch(() => {});
          console.log(`✅ Clicked details button: ${sel}`);
          break;
        }
      }

      // Aspetta che compaiano i toggle/container
      await buttonsContainer.waitFor({ state: 'visible', timeout: 6000 }).catch(() => {
        console.log('⚠️ Timeout aspettando #CybotCookiebotDialogBodyLevelButtons');
      });
    }

    console.log('✅ Cookiebot details in MAIN page (DOM)');
    // A questo punto i toggle devono essere nel main DOM
    return page;
  }

  /**
   * ✅ FIX: Trova il frame Cookiebot verificando la presenza di elementi noti,
   * non matchando per URL (che può essere ambiguo)
   */
  private async getCmpScope(page: Page): Promise<Page | any> {
    try {
      const allFrames = page.frames();
      console.log(`🔍 Total frames on page: ${allFrames.length}`);
      
      // Debug: Log tutti gli URL dei frame
      for (const frame of allFrames) {
        console.log(`  📄 Frame URL: ${frame.url()}`);
      }
      
      // 1) Verifica se il banner Cookiebot è nel main document
      const inPage = page.locator('#CybotCookiebotDialog, #CybotCookiebotDialogBody');
      const isInMainPage = await inPage.first().isVisible().catch(() => false);
      
      if (isInMainPage) {
        console.log(`✅ Cookiebot found in main page - using page scope`);
        return page;
      }
      
      // 2) Cerca in tutti i frame figli (ESCLUDI il main frame)
      for (const frame of allFrames) {
        // Scarta il main frame (che non ha parent)
        if (!frame.parentFrame()) {
          console.log(`  ⏭️  Skipping main frame: ${frame.url()}`);
          continue;
        }
        
        // Cerca elementi Cookiebot in questo frame
        const cookiebotRoot = frame.locator('#CybotCookiebotDialog, #CybotCookiebotDialogBody');
        const hasCookiebot = await cookiebotRoot.first().isVisible().catch(() => false);
        
        if (hasCookiebot) {
          console.log(`✅ Cookiebot found in child frame: ${frame.url()}`);
          return frame;
        }
      }
      
      // 3) Fallback: Risali dall'elemento <iframe> più probabile
      console.log(`🔍 Trying iframe element lookup fallback...`);
      const iframeHost = page.locator(
        'iframe[src*="cookiebot" i], iframe[title*="cookie" i], iframe[id*="cookie" i]'
      ).first();
      
      if (await iframeHost.count() > 0) {
        const contentFrame = await iframeHost.contentFrame();
        if (contentFrame) {
          console.log(`✅ Found frame via iframe element: ${contentFrame.url()}`);
          return contentFrame;
        }
      }
      
      console.log(`⚠️ Cookiebot not found in any frame - using page scope as fallback`);
      return page;
      
    } catch (e) {
      console.log(`❌ Error in getCmpScope, falling back to page: ${e.message}`);
      return page;
    }
  }

  // Set toggle using Locator API only - no problematic evaluate() serialization  
  private async setToggleByLabel(scope: any, label: RegExp, on: boolean, category: string): Promise<boolean> {
    console.log(`🎯 Setting ${category} to ${on ? 'ON' : 'OFF'} with pattern: ${label.source}`);
    
    const row = scope.locator('section, div, li, fieldset').filter({ hasText: label }).first();
    
    if (await row.count() === 0) {
      console.log(`⚠️ No container found for ${category} with pattern: ${label.source}`);
      
      // FALLBACK: Try generic toggle searching
      const fallbackSuccess = await this.setToggleByGenericFallback(scope, category, on);
      if (fallbackSuccess) {
        console.log(`✅ Generic fallback toggle for ${category} completed`);
        return true;
      }
      return false;
    }

    // 1) ARIA role="switch"
    const switchEl = row.getByRole('switch').first();
    if (await switchEl.count() > 0) {
      try {
        const val = await switchEl.getAttribute('aria-checked');
        const isOn = val === 'true';
        if (isOn !== on) {
          await switchEl.click({ force: true });
          console.log(`✅ Toggled ${category} switch to ${on}`);
          return true;
        }
        return true; // Already in desired state
      } catch (e) {
        console.log(`Switch click failed for ${category}:`, e.message);
      }
    }

    // 2) Checkbox
    const cb = row.locator('input[type=checkbox]').first();
    if (await cb.count() > 0) {
      try {
        const checked = await cb.isChecked();
        if (checked !== on) {
          // ✅ FIX COOKIEBOT: Prova prima a cliccare il checkbox normalmente
          try {
            await cb.click({ force: true, timeout: 2000 });
            console.log(`✅ Toggled ${category} checkbox to ${on}`);
            return true;
          } catch (clickError) {
            // Se il checkbox non è cliccabile, prova a cliccare la label associata
            console.log(`🔄 Checkbox not clickable, trying associated label...`);
            
            const cbId = await cb.getAttribute('id');
            if (cbId) {
              const label = scope.locator(`label[for="${cbId}"]`).first();
              if (await label.count() > 0) {
                await label.click({ force: true });
                console.log(`✅ Toggled ${category} via label[for="${cbId}"]`);
                return true;
              }
            }
            
            // Fallback: cerca label parent
            const parentLabel = cb.locator('xpath=ancestor::label').first();
            if (await parentLabel.count() > 0) {
              await parentLabel.click({ force: true });
              console.log(`✅ Toggled ${category} via parent label`);
              return true;
            }
            
            throw clickError; // Re-throw se nessun fallback funziona
          }
        }
        return true; // Already in desired state
      } catch (e) {
        console.log(`Checkbox click failed for ${category}:`, e.message);
      }
    }

    // 3) Button with switch/modal role  
    const btn = row.locator('[role="switch"], button[role="switch"]').first();
    if (await btn.count() > 0) {
      try {
        const pressed = await btn.getAttribute('aria-pressed');
        const isOn = pressed === 'true';
        if (isOn !== on) {
          await btn.click({ force: true });
          console.log(`✅ Toggled ${category} button to ${on}`);
          return true;
        }
        return true; // Already in desired state
      } catch (e) {
        console.log(`Button switch click failed for ${category}:`, e.message);
      }
    }

    console.log(`❌ No toggle found for ${category}`);
    return false;
  }

  // FALLBACK: Generic toggle search when patterns fail
  private async setToggleByGenericFallback(scope: any, category: string, on: boolean): Promise<boolean> {
    try {
      console.log(`🔄 Trying generic fallback for ${category}`);
      
      // Enhanced debug: Capture actual toggle content first
      await this.debugAllToggleElements(scope, category);
      
      // Strategy 1: Direct element scanning in iframe
      try {
        const allPossibleToggles = scope.locator('input, [role="switch"], [data-role="switch"], label + input, .toggle, [data-toggle], .switch, input[type="checkbox"], input[type="radio"]');
        const toggleCount = await allPossibleToggles.count();
        console.log(`🔍 Found ${toggleCount} possible toggle elements in iframe`);
        
        for (let i = 0; i < toggleCount; i++) {
          const toggle = allPossibleToggles.nth(i);
          try {
            // Get text content from surrounding context
            const contextText = await toggle.evaluate(el => {
              return {
                self: el.textContent || '',
                parent: el.parentElement?.textContent || '',
                label: el.closest('label')?.textContent || '',
                previousSibling: el.previousElementSibling?.textContent || '',
                fullContext: el.closest('section, fieldset, div')?.textContent || ''
              };
            });
            
            const allText = `${contextText.self} ${contextText.parent} ${contextText.label} ${contextText.fullContext}`.toLowerCase();
            
            // Enhanced matching
            const isThisCategory = this.enhancedCategoryMatch(allText, category);
            if (isThisCategory) {
              console.log(`🎯 Found potential match for ${category}: "${allText.slice(0, 100)}..."`);
              await toggle.click({ force: true });
              console.log(`✅ Toggled ${category} via enhanced fallback (element ${i})`);
              return true;
            }
          } catch (e) { 
            // Ignore inaccessible elements
          }
        }
      } catch (e) {
        console.log(`❌ Enhanced fallback error for ${category}:`, e.message);
      }
      
      // Strategy 2: Position-based approach (backup)
      const toggleIndex = { analytics: 0, marketing: 1, preferences: 2 }[category];
      try {
        const simpleSwitches = scope.locator('input[type="checkbox"], [role="switch"]');
        const count = await simpleSwitches.count();
        
        if (count > 0 && typeof toggleIndex === 'number' && toggleIndex < count) {
          const targetToggle = simpleSwitches.nth(toggleIndex);
          if (await targetToggle.count() > 0) {
            await targetToggle.click({ force: true });
            console.log(`✅ Toggled ${category} via position-based fallback (index ${toggleIndex})`);
            return true;
          }
        }
      } catch (e) { 
        console.log(`❌ Position fallback failed:`, e.message);
      }
      
      return false;
    } catch (e) {
      console.log(`❌ Generic fallback failed for ${category}:`, e.message);
      return false;
    }
  }

  private async debugAllToggleElements(scope: any, category: string): Promise<void> {
    try {
      const allElements = scope.locator('*');
      const elementCount = await allElements.count();
      console.log(`🐛 DEBUG Category: ${category}, Found ${elementCount} total elements`);
      
      // Get some sample text content for category tuning
      const sampleTexts = await scope.locator('div, label, span, button, input').first().evaluateAll(elements => {
        return Array.from(elements).slice(0, 3).map(el => el.textContent?.trim()).filter(Boolean);
      }).catch(() => []);
      
      if (sampleTexts.length > 0) {
        console.log(`🐛 DEBUG Sample texts:`, sampleTexts);
      }
    } catch (e) {
      console.log(`🐛 DEBUG Error:`, e.message);
    }
  }

  private enhancedCategoryMatch(text: string, category: string): boolean {
    const enhancedMatches = {
      analytics: [
        'analytics', 'analisi', 'performance', 'statistiche', 'statistica', 'statistics',
        'analytique', 'analitiche', 'anal', 'analytics', 'performances', 'stats',
        'trac', 'tracciamento', 'tracking', 'visit', 'visits', 'visitat', 'dati di',
        'google analytics', 'ga', 'analytics cookies', 'performance', 'meeasurement',
        'cookie analytics', 'analytics', 'cookie.*analytics', 'analytics.*cookie',
        'statistica', 'statistiche', 'misurazione', 'misure', 'coldata'
      ],
      marketing: [
        'marketing', 'ads', 'pubblicità', 'commerciale', 'promo', 'target', 
        'advertising', 'pub', 'sponsored', 'targeted', 'personalized', 'adsense',
        'doubleclick', 'marketing', 'marketing cookies', 'advertising cookies', 
        'clickid', 'rétarget', 'conversion', 'campaign'
      ],
      preferences: [
        'preferenz', 'functional', 'funzional', 'technical', 'session', 'necessary',
        'essential', 'core', 'basic', 'fonctionnel', 'indispensable', 'essence'
      ]
    };
    
    const patterns = enhancedMatches[category] || [];
    return patterns.some(keyword => text.includes(keyword.toLowerCase()));
  }

  private categoryMatch(text: string, category: string): boolean {
    const keywords = {
      analytics: ['analytics', 'analisi', 'statistiche', 'performance', 'statistica', 'statistics', 'trac', 'visit'],
      marketing: ['marketing', 'ads', 'pubblicità', 'commerciale', 'promo', 'target', 'advertising'],
      preferences: ['preferenz', 'functional', 'funzional', 'technical', 'session', 'necessari', 'essential']
    };
    
    const catKeywords = keywords[category] || [];
    return catKeywords.some(keyword => text.includes(keyword));
  }

  private async toggleSwitchField(page: Page, category: 'analytics' | 'marketing' | 'preferences', isOn: boolean, cmpName?: string): Promise<boolean> {
    console.log(`🔧 Toggle ${category} to ${isOn ? 'ON' : 'OFF'}`);
    
    // ✅ COOKIEBOT FIX: Usa iframe dettagli invece del main page
    if (cmpName === 'cookiebot') {
      const cookiebotIds = {
        analytics: 'CybotCookiebotDialogBodyLevelButtonStatistics',
        marketing: 'CybotCookiebotDialogBodyLevelButtonMarketing',
        preferences: 'CybotCookiebotDialogBodyLevelButtonPreferences'
      };
      
      const checkboxId = cookiebotIds[category];
      console.log(`🎯 Cookiebot detected - using direct ID: ${checkboxId}`);
      
      try {
        // Trova l'iframe dei dettagli Cookiebot (dove vivono i toggle)
        const detailsScope = await this.getCookiebotDetailsScope(page);
        
        const success = await this.toggleCookiebotCheckbox(detailsScope, checkboxId, isOn, category);
        if (success) {
          console.log(`✅ Successfully toggled ${category} via Cookiebot ID`);
          return true;
        }
      } catch (e) {
        console.log(`❌ Cookiebot details scope failed: ${e.message}`);
      }
      
      console.log(`⚠️ Cookiebot direct ID failed, falling back to pattern matching...`);
    }
    
    // Per altri CMP: usa getCmpScope tradizionale
    const scope = await this.getCmpScope(page);
    
    // Fallback per altri CMP o se Cookiebot ID fallisce
    let selectors: RegExp[] = [];
    
    if (cmpName && this.config.cmp.selectors[cmpName]?.toggles?.[category]) {
      selectors = this.config.cmp.selectors[cmpName].toggles![category] as RegExp[];
    }
    
    if (!selectors || selectors.length === 0) {
      selectors = this.config.cmp.fallback.toggles?.[category] ?? [];
    }
    
    // Try each pattern
    for (const pattern of selectors) {
      const success = await this.setToggleByLabel(scope as any, pattern, isOn, category);
      if (success) return true;
    }
    
    return false;
  }

  /**
   * ✅ Toggle Cookiebot usando label (più affidabile) e verifica stato via .isChecked()
   */
  private async toggleCookiebotCheckbox(scope: Page | Frame, checkboxId: string, isOn: boolean, category: string): Promise<boolean> {
    try {
      const input = scope.locator(`#${checkboxId}`).first();
      const label = scope.locator(`label[for="${checkboxId}"]`).first();

      // Assicurati che almeno uno dei due sia attaccato al DOM
      const exists = (await input.count()) || (await label.count());
      if (!exists) {
        console.log(`❌ Toggle "${category}" non trovato (id: ${checkboxId})`);
        return false;
      }

      // Scrolla qualcosa di cliccabile in vista
      if (await label.count()) {
        await label.scrollIntoViewIfNeeded().catch(() => {});
      } else {
        await input.scrollIntoViewIfNeeded().catch(() => {});
      }

      // Se l'input esiste, usa lo stato reale
      if (await input.count()) {
        const current = await input.isChecked().catch(() => null);
        if (current !== null && current === isOn) {
          console.log(`✅ ${category} già nello stato desiderato`);
          return true;
        }
      }

      // Clicca preferendo il label (di solito è quello visibile)
      const clickable = (await label.count()) ? label : input;
      await clickable.click({ timeout: 4000 }).catch(async () => {
        // Fallback: piccolo tap JS diretto se davvero non è cliccabile
        await scope.evaluate((id) => {
          const inp = document.getElementById(id) as HTMLInputElement | null;
          if (inp) inp.click();
        }, checkboxId);
      });

      // Verifica finale dello stato se possibile
      if (await input.count()) {
        await scope.waitForTimeout(100); // micro debounce
        const final = await input.isChecked().catch(() => null);
        if (final !== null && final !== isOn) {
          // Ritenta una volta
          await clickable.click({ timeout: 4000 }).catch(() => {});
        }
      }

      console.log(`✅ ${category} -> ${isOn ? 'ON' : 'OFF'}`);
      return true;
      
    } catch (error: any) {
      console.log(`❌ toggleCookiebotCheckbox failed for ${category}:`, error?.message);
      return false;
    }
  }

  private async clickConfirmSelected(page: Page, cmpName?: string): Promise<{clicked: boolean; error?: string}> {
    // Try to get CMP-specif confirm selectors
    if (cmpName) {
      const cmpConfig = this.config.cmp.selectors[cmpName];
      if (cmpConfig && cmpConfig.confirmSelected && cmpConfig.confirmSelected.length > 0) {
        for (const selector of cmpConfig.confirmSelected) {
          try{
            const elem = await page.$(selector);
            if (elem && await elem.isVisible()) {
              await elem.click();
              return {clicked: true};
            }
          }
          catch(e) { 
            // Continue searching
          }
        }
      }
    }

    // Fallback text-based searching
    if (this.config.cmp.fallback.confirmSelected && this.config.cmp.fallback.confirmSelected.length > 0) {
      const matchFound = await page.evaluate((searchWords) => {
        const buttons = Array.from(document.querySelectorAll('button, .btn, [role="button"]'));
        for (const btn of buttons) {
          const text = (btn.textContent || '').toLowerCase().trim();
          const matchingWord = searchWords.find(word => text.includes(word.toLowerCase()));
          if (matchingWord) {
            (btn as HTMLElement).click();
            return true;
          }
        }
        return false;
      }, this.config.cmp.fallback.confirmSelected);
      
      if (matchFound) {
        return { clicked: true };
      }
    }
    
    return {clicked: false, error: 'No confirm/save preferences button located'};
  }

  private async handleCustomScenarioFallback(page: Page, scenario: ScenarioMode): Promise<boolean> {
    if (scenario !== 'accept' && scenario !== 'reject') {
      return this.handleCustomScenario(page, scenario, 'any');
    }
    // Original scenario fallback
    return false;
  }

  // DEBUG: Capture iframe content for better pattern matching
  private async debugIframeContent(page: Page): Promise<void> {
    try {
      const frameContent = await page.evaluate(() => {
        const iframeSelectors = [
          'iframe[id*="cookie"], iframe[src*="cookie"]',
          'iframe[id*="consent"], iframe[src*="consent"]', 
          'iframe[id*="privacy"], iframe[src*="privacy"]'
        ].join(',');
        
        const iframes = Array.from(document.querySelectorAll(iframeSelectors));
        if (iframes.length === 0) return null;
        
        const iframe = iframes[0] as HTMLIFrameElement;
        try {
          const frameDoc = iframe.contentDocument || iframe.contentWindow?.document;
          if (!frameDoc) return 'Iframe document not accessible';
          
          // ✅ DEBUG: Cattura struttura checkbox reale
          const checkboxes = frameDoc.querySelectorAll('input[type="checkbox"]');
          const checkboxStructure = Array.from(checkboxes).slice(0, 5).map(cb => {
            const parent = cb.parentElement;
            const computed = frameDoc.defaultView?.getComputedStyle(cb);
            return {
              id: cb.id,
              visible: computed?.display !== 'none' && computed?.visibility !== 'hidden',
              parentTag: parent?.tagName,
              parentClass: parent?.className,
              hasLabel: !!frameDoc.querySelector(`label[for="${cb.id}"]`)
            };
          });
          
          console.log('🐛 CHECKBOX DEBUG:', JSON.stringify(checkboxStructure, null, 2));
          
          // Get all text content from potential toggle sections
          const toggleElements = frameDoc.querySelectorAll('[role="switch"], input[type="checkbox"], button, label, div[class*="cookie"], div[class*="category"]');
          const texts = Array.from(toggleElements).map(el => {
            return {
              tag: el.tagName,
              text: el.textContent?.trim(),
              className: el.className,
              role: el.getAttribute('role'),
              type: el.getAttribute('type')
            };
          }).filter(item => item.text && item.text.length > 0 && item.text.length < 50);
          
          return {
            selector: iframe.src || iframe.id,
            texts: texts
          };
        } catch (err) {
          return 'Cross-origin iframe not accessible';
        }
      });
      
      if (frameContent && typeof frameContent === 'object' && 'texts' in frameContent) {
        console.log(`🐛 DEBUG: Found potential toggle texts in iframe:`, frameContent.texts.slice(0, 5));
      }
    } catch (err) {
      console.log(`🐛 DEBUG: Failed to inspect iframe content:`, err.message);
    }
  }

  private async detectPersonalizeCmpInfo(page: Page): Promise<{
    cmpName?: 'cookiebot' | 'onetrust' | 'iubenda' | 'didomi' | 'usercentrics' | 'generic' | 'unknown';
    matchedBy?: 'config' | 'fallback';
    confirmButtonText?: string;
  }> {
    // Try to detect CMP to best guess
    const oneTrustPresent = await page.$('#onetrust-consent-sdk');
    const cookiebotPresent = await page.$('#CybotCookiebotDialog');
    const iubendaPresent = await page.$('.iubenda-cs-banner');
    
    if (oneTrustPresent) {
      return { cmpName: 'onetrust', matchedBy: 'config' };
    }
    if (cookiebotPresent) {
      return { cmpName: 'cookiebot', matchedBy: 'config' };
    }
    if (iubendaPresent) {
      return { cmpName: 'iubenda', matchedBy: 'config' };
    }
    
    return { cmpName: 'unknown', matchedBy: 'fallback' };
  }
}

// Funzione di utilità per eseguire il test
export async function runConsentTest(input: ConsentTestInput, customScenarios?: Array<ScenarioMode>): Promise<ConsentTestResult> {
  const runner = new ConsentTestRunner();
  return await runner.runTest(input, customScenarios);
}